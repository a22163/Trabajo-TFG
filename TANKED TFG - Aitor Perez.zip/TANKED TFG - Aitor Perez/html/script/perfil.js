const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');
const app = express();

app.use(bodyParser.urlencoded({ extended: true }));

const db = mysql.createConnection({
  host: 'tu-host-de-mysql',
  user: 'tu-usuario-de-mysql',
  password: 'tu-contraseña-de-mysql',
  database: 'tu-nombre-de-base-de-datos'
});

db.connect((err) => {
  if (err) {
    console.error('Error al conectar con la base de datos:', err);
  } else {
    console.log('Conexión exitosa a la base de datos');
  }
});

// Resto de tu configuración de Express...

// Endpoint para obtener la información del usuario desde MySQL
app.get('/api/informacion-usuario', verificarSesion, (req, res) => {
  const nombreUsuario = obtenerNombreUsuario();  // Obtiene el nombre de usuario desde tu lógica
  const sql = `SELECT * FROM usuarios WHERE nombre = '${nombreUsuario}'`;  // Ajusta la consulta SQL según tu estructura de base de datos

  db.query(sql, (err, result) => {
    if (err) {
      console.error('Error al obtener la información del usuario desde MySQL:', err);
      res.status(500).send('Error interno del servidor');
    } else {
      if (result.length > 0) {
        const usuario = result[0];
        res.json(usuario);
      } else {
        res.status(404).send('Usuario no encontrado');
      }
    }
  });
});

// Resto de tus rutas y configuraciones...

const puerto = 3000;
app.listen(puerto, () => {
  console.log(`Servidor iniciado en http://localhost:${puerto}`);
});