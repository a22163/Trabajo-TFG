const images = document.querySelectorAll(".slider-img");
      let currentImageIndex = 0;

      function showImage(index) {
        if (index < 0) {
          index = images.length - 1;
        } else if (index >= images.length) {
          index = 0;
        }

        images.forEach((image, i) => {
          if (i === index) {
            image.style.display = "block";
          } else {
            image.style.display = "none";
          }
        });

        currentImageIndex = index;
      }

      function nextImage() {
        showImage(currentImageIndex + 1);
      }

      function previousImage() {
        showImage(currentImageIndex - 1);
      }

      // Mostrar la primera imagen al cargar la página
      showImage(0);

      // Cambiar automáticamente de imagen cada 3 segundos (ajusta el tiempo según lo necesites)
      setInterval(nextImage, 3000);

      // Boton información
      function showInfo() {
        const infoPopup = document.getElementById("info-popup");
        if (infoPopup.style.display === "block") {
          infoPopup.style.display = "none";
        } else {
          infoPopup.style.display = "block";
        }
      }