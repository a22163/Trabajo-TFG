document.addEventListener('DOMContentLoaded', cargarProductos);

function cargarProductos() {
    const container = document.getElementById('product-container');

    // Realizar una petición AJAX para obtener la lista de productos desde PHP
    fetch('obtener_productos.php')
        .then(response => response.json())
        .then(productos => {
            productos.forEach(producto => {
                const productoHTML = `
                    <div class="product">
                        <img src="${producto.imagen}" alt="${producto.nombre}">
                        <p>Precio: $<span class="precio">${producto.precio}</span></p>
                        <label for="cantidad">Cantidad:</label>
                        <input type="number" name="cantidad" value="0" min="0" max="10">
                    </div>
                `;
                container.innerHTML += productoHTML;
            });
        })
        .catch(error => console.error('Error al cargar productos:', error));
}
