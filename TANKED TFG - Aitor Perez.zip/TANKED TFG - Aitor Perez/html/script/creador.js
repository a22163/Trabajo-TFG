let currentCategory = -1;
let currentImageIndex = -1;
let currentImages = [];

function loadImages(categoryIndex) {
    if (currentCategory === categoryIndex) {
        return;
    }

    currentCategory = categoryIndex;
    currentImages = document.getElementById(`sub-menu-${categoryIndex}`).getElementsByTagName("img");
    currentImageIndex = -1;
    showSelectedImage();
}

function selectImage(imageSrc) {
    currentImageIndex = Array.from(currentImages).findIndex(img => img.src.includes(imageSrc));
    showSelectedImage();
}

function showSelectedImage() {
    if (currentImageIndex >= 0 && currentImageIndex < currentImages.length) {
        document.getElementById("selected-image").src = currentImages[currentImageIndex].src;
    } else {
        document.getElementById("selected-image").src = "";
    }
}

function changeImage(offset) {
    if (currentImageIndex >= 0 && currentImageIndex < currentImages.length) {
        currentImageIndex += offset;
        if (currentImageIndex < 0) {
            currentImageIndex = currentImages.length - 1;
        } else if (currentImageIndex >= currentImages.length) {
            currentImageIndex = 0;
        }
        showSelectedImage();
    }
}

// Cargar imágenes de la primera categoría por defecto
loadImages(0);
