document.addEventListener("DOMContentLoaded", function() {
    const messageForm = document.getElementById("messageForm");
    const messageInput = document.getElementById("messageInput");
    const imageInput = document.getElementById("imageInput");
    const messagesList = document.getElementById("messages");

    messageForm.addEventListener("submit", function(event) {
        event.preventDefault();
        const formData = new FormData(messageForm);
        sendMessage(formData);
    });

    function sendMessage(formData) {
        fetch("enviar_mensaje.php", {
            method: "POST",
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showMessage(data.message);
                messageInput.value = "";
                imageInput.value = "";
            } else {
                alert("Error al enviar el mensaje");
            }
        })
        .catch(error => {
            console.error("Error en la solicitud fetch:", error);
        });
    }

    function showMessage(message) {
        const li = document.createElement("li");
        li.className = "message";
        li.innerHTML = message;
        messagesList.appendChild(li);
    }
});
