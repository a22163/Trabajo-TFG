<?php
// Simulación de datos desde MySQL
$categories = ["Categoria 1", "Categoria 2", "Categoria 3"];
$images = [
    ["img1.jpg", "img2.jpg", "img3.jpg"],
    ["img4.jpg", "img5.jpg", "img6.jpg"],
    ["img7.jpg", "img8.jpg", "img9.jpg"]
];
?>

<ul class="categories">
    <?php foreach ($categories as $index => $category): ?>
        <li class="category" onclick="loadImages(<?php echo $index; ?>)">
            <?php echo $category; ?>
        </li>
    <?php endforeach; ?>
</ul>

<?php foreach ($images as $index => $categoryImages): ?>
    <ul class="sub-menu" id="sub-menu-<?php echo $index; ?>">
        <?php foreach ($categoryImages as $image): ?>
            <li onclick="selectImage('<?php echo $image; ?>')">
                <img src="<?php echo $image; ?>" alt="Imagen">
            </li>
        <?php endforeach; ?>
    </ul>
<?php endforeach; ?>