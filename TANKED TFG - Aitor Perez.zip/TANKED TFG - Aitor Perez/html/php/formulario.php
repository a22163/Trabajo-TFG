<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recoger datos del formulario
    $nombre = htmlspecialchars($_POST["nombre"]);
    $email = htmlspecialchars($_POST["email"]);
    $mensaje = htmlspecialchars($_POST["mensaje"]);


    // Enviar correo 
    $destino = "tanked@gmail.com";
    $asunto = "Nuevo mensaje de contacto de $nombre";
    $cuerpoMensaje = "Nombre: $nombre\nCorreo Electrónico: $email\nMensaje: $mensaje";

    mail($destino, $asunto, $cuerpoMensaje);

    // Redirigir o mostrar un mensaje de éxito
    header("Location: gracias.html");
    exit();
}
?>

