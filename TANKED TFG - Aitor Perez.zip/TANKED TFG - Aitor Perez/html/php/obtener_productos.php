<?php
// Establecer conexión
include 'conexion.php';

// Consulta para obtener la lista de productos
$sql = "SELECT id, nombre, precio, imagen FROM productos";
$result = $conn->query($sql);

// Verificar si hay resultados
if ($result->num_rows > 0) {
    // Iterar sobre los resultados y generar la lista de productos
    $productos = array();
    while ($row = $result->fetch_assoc()) {
        $productos[] = $row;
    }

    // Devolver la lista de productos como JSON
    echo json_encode($productos);
} else {
    echo "No se encontraron productos";
}

// Cerrar conexión
$conn->close();
?>
