<?php
require 'conexion.php';

if(isset($_POST['registro'])) {
    // Obtener los valores enviados por el formulario
    $nombre = $_POST['name'];
    $apellidos = $_POST['last_name'];
    $usuario = $_POST['username'];
    $telefono = $_POST['phone'];
    $correo = $_POST['email'];
    $contrasena = $_POST['password'];
    $ciudad = $_POST['ciudad'];

    // Insertar los datos en la base de datos
    $sql = "INSERT INTO usuarios (name, last_name, username, phone, email, password, ciudad) 
            VALUES ('$nombre', '$apellidos', '$usuario', '$telefono', '$correo', '$contrasena', '$ciudad')";

    $resultado = mysqli_query($conexion, $sql);

    if($resultado) {
        echo "¡Se insertaron los datos correctamente!";
		// Redireccionar a main.html después de 3 segundos
        header("refresh:3;url=main.html");
    } else {
        echo "Error al insertar los datos: " . mysqli_error($conexion);
    }
}
?>
