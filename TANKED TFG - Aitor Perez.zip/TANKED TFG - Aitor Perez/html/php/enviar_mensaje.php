<?php

// Establecer conexión
include 'conexion.php';

// Manejar la solicitud POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtener datos del formulario
    $mensaje = $_POST["mensaje"];

    // Verificar si se cargó una imagen
    $imagen = "";
    if (isset($_FILES["imagen"]) && $_FILES["imagen"]["error"] == 0) {
        $imagen = guardarImagen();
    }

    // Insertar el mensaje en la base de datos
    $usuario_id = 1; // Debes obtener el ID del usuario actual (aquí es solo un ejemplo)
    $sql = "INSERT INTO mensajes (usuario_id, mensaje, imagen) VALUES ($usuario_id, '$mensaje', '$imagen')";
    
    if ($conn->query($sql) === TRUE) {
        // Éxito
        $response = array("success" => true, "message" => "Mensaje enviado correctamente");
    } else {
        // Error
        $response = array("success" => false, "message" => "Error al enviar el mensaje: " . $conn->error);
    }

    echo json_encode($response);
}

// Cerrar conexión
$conn->close();

function guardarImagen() {
    $targetDir = "uploads/"; // Directorio donde se guardarán las imágenes
    $targetFile = $targetDir . basename($_FILES["imagen"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

    // Verificar si el archivo es una imagen real
    if (isset($_POST["submit"])) {
        $check = getimagesize($_FILES["imagen"]["tmp_name"]);
        if ($check !== false) {
            $uploadOk = 1;
        } else {
            $uploadOk = 0;
        }
    }

    // Verificar si el archivo ya existe
    if (file_exists($targetFile)) {
        $uploadOk = 0;
    }

    // Verificar el tamaño del archivo
    if ($_FILES["imagen"]["size"] > 500000) {
        $uploadOk = 0;
    }

    // Permitir solo ciertos formatos de archivo
    if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
        $uploadOk = 0;
    }

    // Verificar si $uploadOk es 0 por algún error
    if ($uploadOk == 0) {
        return "";
    } else {
        // Intentar mover el archivo al directorio de destino
        if (move_uploaded_file($_FILES["imagen"]["tmp_name"], $targetFile)) {
            return $targetFile;
        } else {
            return "";
        }
    }
}
?>

