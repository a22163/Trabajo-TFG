<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Creador3D | TAKED</title>
    <link rel="stylesheet" href="css/creador.css">
</head>
<body>
    <header>
        <div class="logo">
          <a href="main.html">
          <img src="imagenes/Logobc.png" alt="Logo de Mi Sitio Web" />
        </a>
        </div>
  
        <div class="nav-links">
          <a href="main.html">Inicio</a>
          <a href="creador.html">Creador</a>
          <a href="calculadora.html">Calculadora</a>
          <a href="blog.html">Blog</a>
          <a href="contacto.html">Contacto</a>
          <div id="nombreUsuarioArea" style="float: right;">
            <a href="perfil.html">Ver perfil</a>
          </div>
        </div>
      </header>

      <div class="container">
        <div class="menu">
            <?php include("menu.php"); ?>
        </div>
        <div class="content">
            <div id="image-container">
                <img id="selected-image" src="" alt="Imagen seleccionada">
            </div>
            <div class="navigation">
                <button onclick="changeImage(-1)">Anterior</button>
                <button onclick="changeImage(1)">Siguiente</button>
            </div>
        </div>
    </div>
      <script src="script/creador.js"></script>
</body>
</html>